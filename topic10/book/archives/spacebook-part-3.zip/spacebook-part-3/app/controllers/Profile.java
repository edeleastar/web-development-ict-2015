package controllers;

import play.*;
import play.mvc.*;

import java.util.*;

import models.*;

public class Profile extends Controller
{
  public static void index()
  {
    String userId = session.get("logged_in_userid");
    User user = User.findById(Long.parseLong(userId));
    render(user);
  }
  
  public static void changeStatus(String profiletext)
  {
    Logger.info("Status changed to " + profiletext);
    index();
  }  
}